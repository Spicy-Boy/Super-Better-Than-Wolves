# BTW-source

BTW Community Edition

## Submitting code

- Decompile a fresh vanilla jar using mcp (this is necessary to generate files needed to recompile and reobfuscate)
- Delete the contents of src
- Fork the BTW repo
- Clone your forked BTW source repo into the src folder
- Set the branch to vanilla
- Recompile
- Run updatemd5
- Switch branch to main
- Grab the btw resources and put the contents (not the resources folder itself) inside bin/minecraft AND eclipse/client/bin (eclipse/client/bin is needed for them to show up in game, bin/minecraft is where the scripts will get it from)

Once you are done, submit your code as a pull request back to the main repo and we will review it.

## For add-on authors
(Until the BTW-Public source patches are available)

- Decompile a fresh vanilla jar using mcp (this is necessary to generate files needed to recompile and reobfuscate)
- Delete the contents of src
- Copy BTW source from the latest release tag into src
- Grab the btw resources and put  the contents (not the resources folder itself) inside bin/minecraft AND eclipse/client/bin (eclipse/client/bin is needed for them to show up in game, bin/minecraft is where the scripts will get it from)
- Recompile
- Run updatemd5

### Using git for your addon

The easiest way I have found to handle git with addons is to have the repo inside the modsrc folder, and run getchangedsrc to update the code there for adding it to git. This makes it so that you don't have to worry about complicated gitignores, or manually managing base class edits in the gitignore.

### Updating addons to a new BTW version

- Run getchangedsrc to make sure your addon code in modsrc is up to date
- Replace the code in src with the latest BTW version source
- Recompile
- Run updatemd5
- Copy your code from modsrc back into src (after accounting for potential changes in shared base classes)
