package argo.jdom;

interface JsonListenerToJdomAdapter_NodeContainer
{
    void addNode(JsonNodeBuilder var1);

    void addField(JsonFieldBuilder var1);
}
