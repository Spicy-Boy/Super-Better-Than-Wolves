package net.minecraft.src;

public class BlockOreStorage extends Block
{
    public BlockOreStorage(int par1)
    {
        super(par1, Material.iron);
        this.setCreativeTab(CreativeTabs.tabBlock);
    }
}
