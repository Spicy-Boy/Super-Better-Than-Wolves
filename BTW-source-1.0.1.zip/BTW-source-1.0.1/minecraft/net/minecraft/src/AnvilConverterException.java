package net.minecraft.src;

public class AnvilConverterException extends Exception
{
    public AnvilConverterException(String par1Str)
    {
        super(par1Str);
    }
}
