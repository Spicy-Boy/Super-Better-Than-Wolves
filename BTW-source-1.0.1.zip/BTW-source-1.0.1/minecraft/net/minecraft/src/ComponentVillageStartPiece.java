package net.minecraft.src;

import java.util.ArrayList;
import java.util.Random;

public class ComponentVillageStartPiece extends ComponentVillageWell
{
    public final WorldChunkManager worldChunkMngr;

    /** Boolean that determines if the village is in a desert or not. */
    public final boolean inDesert;

    /** World terrain type, 0 for normal, 1 for flap map */
    public final int terrainType;
    public StructureVillagePieceWeight structVillagePieceWeight;

    /**
     * Contains List of all spawnable Structure Piece Weights. If no more Pieces of a type can be spawned, they are
     * removed from this list
     */
    public ArrayList structureVillageWeightedPieceList;
    public ArrayList field_74932_i = new ArrayList();
    public ArrayList field_74930_j = new ArrayList();

    public ComponentVillageStartPiece(WorldChunkManager par1WorldChunkManager, int par2, Random par3Random, int par4, int par5, ArrayList par6ArrayList, int par7)
    {
        super((ComponentVillageStartPiece)null, 0, par3Random, par4, par5);
        this.worldChunkMngr = par1WorldChunkManager;
        this.structureVillageWeightedPieceList = par6ArrayList;
        this.terrainType = par7;
        BiomeGenBase var8 = par1WorldChunkManager.getBiomeGenAt(par4, par5);
        this.inDesert = var8 == BiomeGenBase.desert || var8 == BiomeGenBase.desertHills;
        this.startPiece = this;
    }

    public WorldChunkManager getWorldChunkManager()
    {
        return this.worldChunkMngr;
    }
    
    // FCMOD: Code added
    private int m_iAbandonmentLevel;  // 0 = not abandoned, 1 = partially abandoned 2 = fully abandonded
    private int m_iPrimaryCropBlockID;
    private int m_iSecondaryCropBlockID;
    private boolean m_bModSpecificDataInitialized = false;

    public int GetAbandonmentLevel( World world )
    {
    	CheckIfModSpecificDataRequiresInit( world );
    	
    	return m_iAbandonmentLevel;
    }
    
    public int GetPrimaryCropBlockID( World world )
    {
    	CheckIfModSpecificDataRequiresInit( world );
    	
    	return m_iPrimaryCropBlockID;
    }
    
    public int GetSecondaryCropBlockID( World world )
    {
    	CheckIfModSpecificDataRequiresInit( world );
    	
    	return m_iSecondaryCropBlockID;
    }
    
    private void CheckIfModSpecificDataRequiresInit( World world )
    {
    	if ( !m_bModSpecificDataInitialized )
    	{
    		InitializeModSpecificData( world );    		
    	}
    }
    
    private void InitializeModSpecificData( World world )
    {    	
		m_bModSpecificDataInitialized = true;
		m_iAbandonmentLevel = 0;
    	
    	int iSpawnX = world.getWorldInfo().getSpawnX();
    	int iSpawnZ = world.getWorldInfo().getSpawnZ();
    	
    	int iVillageX = boundingBox.getCenterX();
    	int iVillageZ = boundingBox.getCenterZ();
    	
    	double dDeltaX = (double)( iSpawnX - iVillageX );
    	double dDeltaZ = (double)( iSpawnZ - iVillageZ );
    	
    	double dDistSqFromSpawn = dDeltaX * dDeltaX + dDeltaZ * dDeltaZ;
    	double dAbandonedRadius = FCUtilsHardcoreSpawn.GetAbandonedVillageRadius();
    	
    	if ( dDistSqFromSpawn < ( dAbandonedRadius * dAbandonedRadius ) )
    	{
    		m_iAbandonmentLevel = 2;
    	}
    	else
    	{
    		double dPartiallyAbandonedRadius = FCUtilsHardcoreSpawn.GetPartiallyAbandonedVillageRadius();
    		
    		if ( dDistSqFromSpawn < ( dPartiallyAbandonedRadius * dPartiallyAbandonedRadius ) )
    		{    		
        		m_iAbandonmentLevel = 1;
        		
    			m_iPrimaryCropBlockID = FCBetterThanWolves.fcBlockWheatCrop.blockID;
    			m_iSecondaryCropBlockID = FCBetterThanWolves.fcBlockWheatCrop.blockID;
    		}
    		else
    		{	
    			m_iPrimaryCropBlockID = FCBetterThanWolves.fcBlockWheatCrop.blockID;
    			
    			int iRandomFactor = world.rand.nextInt( 6 ); 
    			
    			if ( iRandomFactor == 5 )
    			{
    				m_iSecondaryCropBlockID = Block.potato.blockID;
    			}
    			else if ( iRandomFactor == 4 )
    			{
    				m_iSecondaryCropBlockID = Block.carrot.blockID;
    			}
    			else
    			{
    				m_iSecondaryCropBlockID = FCBetterThanWolves.fcBlockWheatCrop.blockID;
    			}
    		}
    	}
    }
    // END FCMOD
}
